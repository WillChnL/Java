import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

//************************************************************************
//  PassWordCreator.java       Author: Richard Chan
//
//  Demonstrates the use of a TextField and a GridPane.
//************************************************************************

public class PassWordCreator extends Application
{
    //--------------------------------------------------------------------
    //  Launches the password creator application.
    //--------------------------------------------------------------------
    public void start(Stage primaryStage)
    {
        Scene scene = new Scene(new PassWordPane(), 600, 250);
        
        primaryStage.setTitle("PassWord Creator");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    public static void main(String[] args)
    {
        launch(args);
    }
}