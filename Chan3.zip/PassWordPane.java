import javafx.event.ActionEvent;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;

//************************************************************************
//  PassWordPane.java       Author: Richard Chan
//  Demonstrates the use of a TextField and a GridPane.
//************************************************************************

public class PassWordPane extends GridPane
{
    private Label result;
    private TextField pass, day;

    //--------------------------------------------------------------------
    //  Sets up a GUI containing a labeled text field for password
    //  creator.
    //--------------------------------------------------------------------
    public PassWordPane()
    {
        Font font = new Font(18);
        
        Label centerLabel = new Label("Password Creator");
        centerLabel.setFont(font);
        GridPane.setHalignment(centerLabel, HPos.RIGHT);
        
        Label inputLabel = new Label("Your Name:");
        inputLabel.setFont(font);
        GridPane.setHalignment(inputLabel, HPos.RIGHT);
        
        Label outputLabel = new Label("6-Digit Birthday:");
        outputLabel.setFont(font);
        GridPane.setHalignment(outputLabel, HPos.RIGHT);
        
        result = new Label("---");
        result.setFont(font);
        GridPane.setHalignment(result, HPos.CENTER);
        
        pass = new TextField();
        pass.setFont(font);
        pass.setPrefColumnCount(5);
        pass.setAlignment(Pos.CENTER);
        pass.setOnAction(this::processReturn);
        
        day = new TextField();
        day.setFont(font);
        day.setPrefColumnCount(5);
        day.setAlignment(Pos.CENTER);
        day.setOnAction(this::processReturn1);
        
        setAlignment(Pos.CENTER);
        setHgap(20);
        setVgap(10);
        setStyle("-fx-background-color: red");
        
        add(centerLabel, 0, 0);
        add(inputLabel, 0, 1);
        add(pass, 1, 1);
        add(outputLabel, 0, 2);
        add(day, 1, 2);
        add(result, 0, 3);
    }
    
    //--------------------------------------------------------------------
    //  Computes and displays the password when the user
    //  presses the return key while in the text field.
    //--------------------------------------------------------------------
    public void processReturn(ActionEvent event)
    {
        int ran = (int)(Math.random() * 100);
        result.setText("The Pasword is: " + pass.getText(0,2) + '.' + ran);
    }
    public void processReturn1(ActionEvent event)
    {
        int ran = (int)(Math.random() * 100);
        result.setText("The Pasword is: " + pass.getText(0,2) + '.' + ran + day.getText(2,6));
    }
}
