/**
 *This program ask for a Double Value 
 *and split it into Dollars bills and Coins
 *Author Richard Chan
 *Date 01/26/2018
*/

import java.util.Scanner;
public class Money
{
  public static void main(String[] args)
 {
        
    Scanner KB = new Scanner(System.in);
        
    System.out.println("Amount due in $?");
    double money  = KB.nextDouble();
    
    int balance = (int)(money * 100);
          
    int dll = balance / 100;
    balance =  balance % 100;
    
    int five = dll / 5;
    dll = dll % 5;
    
    int ten = five / 2;
    five = five % 2;
 
    int quarter = balance / 25;
    balance = balance % 25;
 
    int dime = balance / 10;
    balance = balance % 10;
 
    int nickel = balance / 5;
    balance = balance % 5;
     
    int pennie = balance;
    
 
    System.out.println(ten + " ten dollar bills \n" + five + " five dollar bills \n" + dll + 
                       " one dollar bills \n" + quarter + " quarter \n" + dime + " dime \n" 
                       + nickel + " nickel \n" + pennie + " pennie");
 
         
 }
}