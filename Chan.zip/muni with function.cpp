#include <iostream>
using namespace std;

// this is called a function prototype or function declaration
// it must contain the interface of a function

void getMuniInfo(int& nrparm, int& ndparm, char mnparm[]);
/* 
   this function will get the values from the user at the keyboard
   for the number of riders, the number of days 
   and the name of the muni line
*/

void calcRidership(int nrp, int ndp, double& a);
// returns the average ridership of a muni line

void displayMuniInfo(int, int, char[], double);
// this function displays all the info

int main()
{
  int number_riders, num_days;
  char muni_name[51];
  double aveRidership;
  
  getMuniInfo(number_riders, num_days, muni_name); // function invocation
  calcRidership(number_riders, num_days, aveRidership); // fun invoc
  displayMuniInfo(number_riders, num_days, muni_name, aveRidership); //fun invoc

  cout << "\nThe address of variable aveRidership is " << &aveRidership << endl << endl;

  return 0;
}

// this is called the function definition
void getMuniInfo(int& nrparm, int& ndparm, char mnparm[]) //fun header
{
  cout << "\nWelcome to the Muni Ridership Calculator.\n";
  cout << "Which Muni line did you survey?  ";
  cin >> mnparm;
  cout << "How many days did you survey it?  ";
  cin >> ndparm;
  cout << "How many people riders did you count?  ";
  cin >> nrparm;

  return; // returns to where the function was invoked
} // everything in brackets is the function body

void calcRidership(int nrp, int ndp, double& a)
{
   a = nrp/static_cast<double>(ndp);
   return;
}

void displayMuniInfo(int nr, int nd, char n[], double a)
{
  cout << "According to your survey, "
       << nr << " riders rode the " << n << " in " << nd << " days." <<  endl
       << "That means an average of "  << a  
       << " people rode the bus per day.\n";
  // The static_cast above is necessary to get a decimal answer
  // (not one with the fractional part cut off)

  return;
}
