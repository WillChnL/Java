/**
 *This program ask some questions to  
 *create a history with a "BIG-String"
 *Author Richard Chan
 *Date 01/26/2018
*/

import java.util.Scanner;
public class MadLib
  {
  
     public static void main(String[] args)
       {
        
         Scanner KB = new Scanner(System.in);
        
         System.out.println("Please answer each question to create a funny story!");
         
         System.out.print("Enter a number: ");
         int num  = KB.nextInt();
         KB.nextLine();
         
         System.out.print("Enter a adjective: ");
         String adj  = KB.nextLine();   
         
         System.out.print("Enter a verb (past tense): ");
         String verb  = KB.nextLine();  
         
         System.out.print("Enter a adjective: ");
         String adj2  = KB.nextLine(); 
         
         System.out.print("Enter a 'ing' verb: ");
         String ing  = KB.nextLine();  
         
         System.out.print("Enter a noun: ");
         String noun  = KB.nextLine();  
         
         System.out.print("Enter a famous person: ");
         String fam  = KB.nextLine(); 
         System.out.println();
         
         System.out.println("One day a " + adj + " ghost " + verb + " across the street while carrying a " + adj2 + 
                            " bucket full of dynamite. Then it came across " + num + " " + noun + " that were " + ing + 
                            " at a child.");
         System.out.println();
                            
         System.out.println("This is a story written by " + fam + ".");
         
  }
}
 