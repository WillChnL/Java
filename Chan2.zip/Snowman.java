//************************************************************************
//  Snowman.java       Author: Richard Chan
//
//  Drawing a Snowman with shapes in JavaFX
//************************************************************************

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.text.Text;

public class Snowman extends Application
{
    public void start(Stage primaryStage)
    {        
      
        Ellipse frown = new Ellipse(100, 80, 12, 7);
        frown.setFill(Color.BLACK);
        
        Ellipse frown2 = new Ellipse(100, 83, 12, 7);
        frown2.setFill(Color.WHITE);
        
        Ellipse base = new Ellipse(100, 210, 80, 60);
        base.setFill(Color.WHITE);

        Ellipse middle = new Ellipse(100, 130, 50, 40);
        middle.setFill(Color.WHITE);

        Circle head = new Circle(100, 70, 30);
        head.setFill(Color.WHITE);

        Circle rightEye = new Circle(90, 60, 5);
        Circle leftEye = new Circle(110, 60, 5);
        
        Circle topButton1 = new Circle(100, 100, 6);
        topButton1.setFill(Color.RED);
        Circle topButton = new Circle(100, 120, 6);
        topButton.setFill(Color.RED);
        Circle bottomButton = new Circle(100, 140, 6);
        bottomButton.setFill(Color.RED);

        Line leftArm = new Line(130, 130, 180, 130);
        leftArm.setStrokeWidth(3);
        Line rightArm = new Line(70, 130, 20, 100);
        rightArm.setStrokeWidth(3);

        Rectangle stovepipe = new Rectangle(80, 0, 40, 50);
        Rectangle brim = new Rectangle(70, 45, 60, 5);
        Group hat = new Group(stovepipe, brim);
        hat.setTranslateX(10);
        hat.setRotate(15);

        Group snowman = new Group(base, middle, head,frown, frown2, leftEye, rightEye,
              topButton1, topButton, bottomButton, leftArm, rightArm, hat);
        snowman.setTranslateX(170);
        snowman.setTranslateY(50);
        
        Text name = new Text(20, 20, "Richard Chan");

        Circle sun = new Circle(450, 50, 30);
        sun.setFill(Color.GOLD);

        Rectangle ground = new Rectangle(0, 250, 500, 100);
        ground.setFill(Color.STEELBLUE);

        Group root = new Group(ground, sun, snowman, name);
        Scene scene = new Scene(root, 500, 350, Color.LIGHTBLUE);

        primaryStage.setTitle("Snowman");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args)
    {
        launch(args);
    }
}